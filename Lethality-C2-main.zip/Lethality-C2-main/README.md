#
**LETHALITY C2**
#  


#
**Disclaimer**
#
This project was created for educational purposes and personal use only.

DISCLAIMER: This software is provided "as is" without any warranty. Usage is at your own risk. The developers assume no liability for any misuse or damage caused by this program.



This is a python based C2 server made as a class project. It has a command execution module, DDOS module (working on displaying it's output), Keylogger module and also supports payload generation.
The server runs on flask. The interface could be better but too lazy. Make sure to install the requirements before using it.

`pip install -r requirements.txt
`


After Installing the required dependencies. Run the server.

`
python server.py
`


Also change the IP's and port's in the clients files, to match that of your servers. Note, that this is a work in progress. You'll notcie many stuff out of place.

![image](https://github.com/maidennless/Lethality-C2/assets/151864755/cac9589f-5e06-4343-9c0e-80b3a2189cce)


#
**Ip for Windows**
#

You can find ip using

`
ipconfig
`


#
**Ip for Linux**
#
You can find ip using
`
ifconfig
`




> Also note that, after starting the server, you need to open the web server to actually catch any bots.
