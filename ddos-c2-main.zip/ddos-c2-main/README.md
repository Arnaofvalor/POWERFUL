# ddos-c2
TOOLS BY SZT00XPLOIT X SISURYA OFFICIALKU

INI TOOLS GRATIS YA DEK JANGAN DIJUAL
Step 1: Install Termux


Step 2: Buka Termux

pkg update
pkg upgrade
pkg install python
pkg install python-pip
pip install pycryptodome
pkg install git
https://github.com/Szt00Xploit2/ddos-c2/
cd ddos-c2
python ddosSzt.py

