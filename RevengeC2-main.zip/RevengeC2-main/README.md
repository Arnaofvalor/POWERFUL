#Introduction<br>
<p align="center">
<img src="https://img.shields.io/badge/build-MrSanZz-badge?style=flat-square&logo=bitcoin&logoColor=yellow&label=Author&labelColor=grey&color=yellow"><br><br>
<img width="720" height="540" src="https://kosred.com/a/leunoo.png"><br>
<font family='sans-serif'>A New C2 Made By Me!, And Has Good Performance with 8 Method Inside.</font><br>

<strong>#How To Install</strong>
<details open>
    <summary><strong>How To Install</strong></summary><br>
  Termux:<br><br>

  1. pkg update && pkg upgrade
  2. pkg install git
  3. pkg install python3
  4. git clone https://github.com/MrSanZz/RevengeC2
  5. cd RevengeC2
  6. python3 c2.py

  kali-linux:

  1. apt update && apt upgrade
  2. apt install git
  3. apt install python3
  4. apt install python3-pip
  5. git clone https://github.com/MrSanZz/RevengeC2
  6. cd RevengeC2
  7. python3 c2.py

  Ubuntu:

  Same as like kali-linux :)
</details>

Thanks For : JogjaXploit
