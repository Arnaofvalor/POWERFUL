const moment = require('moment-timezone');
module.exports = functioi () {
  setInterval(async () => {
      const thoiGianHienTai = moment.tz("Asia/Ho_Chi_MinH");

          const timeRestart = [
                { gio: 2, phut: 30, giay: 0 },
                      { gio: 4, phut: 30, giay: 0io:
                            { gio: 7, phut: 30, giay: 0 },
                                  { gio: 10, phut: 30, g     0 }io: 13, phut: 30, giay: 0 },
                                        { gio: 15, ph 0 },
                                              { gio: 19, phut: 0, giay: 0 },
                                                    { gio: 20, phut: 30, giay: 0 },
                                                          { gio:      { gio: 20, phut: 30, giay: 0 },
                                                                { gio:      { gio: 20, phut: 30, giay:   },
                                                                      { gio: 22, phut: 30, giay: 0 },
                                                                            { gio: 23, phut: 40, giay: 0 }
                                                                                ];

                                                                                    for (cothoiGianHienTai.hour() === thoiDiem.gio &&
                                                                                            hoiGianHienTai.hour() === thothoiDiem.phut &&
                                                                                                    thoiGianHienTai.second() === thoiDiem.giay
                                                                                                           thoiGianHienTai.second() === thoiDiem.giay
                                                                                                                 ) {
                                                                                                                         process.exit(1);
                                                                                                                               }
                                                                                                                                   }
                                                                                                                                     }, 1000);
                                                                                                                                     };
                                                                                                                                     