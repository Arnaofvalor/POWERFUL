require './routes/auth'
require './routes/core'
require './routes/c2'
require './routes/ui'