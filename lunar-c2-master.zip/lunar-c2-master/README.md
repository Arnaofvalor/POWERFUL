# Lunar-C2
This is an open source Command and Control framework designed for use with the Gray Gopher Remote Access Tool, and any other asynchronous HTTP payloads I may end up developing. 